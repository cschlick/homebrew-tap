# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.0] - 2026-09-21

### Added

- **`gw explain [node [node]] [--since 24h]` — the story, on demand.** One command merges the four memories this machine already holds — the audit trail's events and operations (told in `gw narrate`'s language), the replicated membership decisions (a revoke/leave/caps-change shows up here even when it was decided on another holder), the credential history, and peers' endpoint testimony — into a chronological narrative plus a current-state verdict (credential, confirmations or the mirage warning, live handshake when permitted, and for a pair: whether policy even allows the tunnel). Departed nodes still resolve by name through the tombstone's memory, so `gw explain bb` works *after* bb left. Read-only, no root.
- **Endpoint attestations — reachability as verified fact.** Advertised endpoints are heuristic claims (the field produced a VM-internal ULA and a VPN's shared /128, both convincing, both dead); every fresh WireGuard handshake is ground truth. Each node now signs testimony per live tunnel ("my link to S rides E", straight from `wg show`) every ~2 minutes and hands it to a holder (`POST /attest`); holders aggregate (self-signed, membership-gated, latest-wins, 30-minute freshness) and serve it in `/directory`, where every node's sync picks it up. `gw watch` gains a `confirmed` line: ✓ by N peers when testimony matches the advertisement, or a loud MIRAGE warning when peers only ever reach the node at some *other* address — the exact signature of both incidents, now a header line instead of an outage. `gw invite` runs the same check on the hosts it bakes into a token and warns before a joiner can hang on them. Attestations are diagnostic only — they never feed issuance, policy, or peering.

### Removed

- **Port enforcement is gone — greasewood filters no ports, on any platform.**
  The doctrine sharpened: greasewood decides *which machines can talk* (tunnel
  existence, derived from the grant table — pure software, byte-identical on
  Linux and macOS); what flows *inside* a granted tunnel is the host firewall's
  business. The nftables layer that realized each grant's `ports` list
  (`portfilter.py`, the per-mesh `table inet greasewood_<mesh>`, the
  `enforce_ports` config key and `--no-enforce-ports` flag, the
  enforcement-degraded breadcrumb) is removed, along with the pf backend that
  was planned to mirror it on macOS — that question is now answered "no, by
  design" instead of "not yet". A grant's `ports` field remains valid syntax
  and is displayed as the connection's recorded intent. Upgrading is
  automatic: a 0.7 daemon deletes any leftover legacy table at startup, and
  `gw watch` strips one from its host-firewall view in the meantime. The
  firewall guidance (`gw firewall`, docs) now recommends admitting the overlay
  coarsely — the grant table already decided who is on it — and narrowing per
  port yourself if you want to; `gw watch` treats either posture as healthy.
  The `--json` snapshot schema bumps to `gw.watch/v2` (the
  `mesh.enforce_ports` / `mesh.enforcement_degraded` keys left).

### Changed

- **`cli.py` (6,080 lines) is now the `greasewood.cli` package** — nine modules cut along the command families: `_common` (gates, membership slots, anchor authority), `netdetect` (the twice-bitten address heuristics, finally in their own tested home), `svc`, `bootstrap` (create/invite/join + the door dance), `membership`, `anchorcmds`, `certcmds`, `daemon` (the `cmd_run` assembly), and `parser`. Pure refactor: zero behavior change, the full suite passes untouched. The package namespace stays the single address — every name re-exported, cross-module helpers called late-bound through it — so `from greasewood import cli; cli.<anything>` (including every monkeypatch in the test suite) works exactly as before.

### Fixed

- **The fleet-renew hint gossips between holders.** `gw renew-all` on holder A only nudged the nodes whose first-success sync happened to pull from A; holders now adopt a newer `renew_after` seen in pulls from other holders (latest-wins, like statements), so the hint reaches every node from whichever holder it polls.
- **Hostname collisions alarm in the watch header.** The active/active enrollment race was documented as "accepted but loud" — it now actually is: two LIVE identities claiming one sanitized name raise a COLLISION header line naming both ids and the fix; a stale expired record aging out under a re-enrolled name stays quiet (normal lifecycle).
- Dropped the CI bottle-chain job: GitHub's macOS runners lag the OS a version, so their bottles carry the wrong tag for current Macs and it failed (harmlessly, redly) on every release. Bottles are built by hand per the formula's documented procedure; the release workflow now ends green at the GitHub Release.

## [0.6.0] - 2026-09-21

### Changed — the anchor is now a FILE, and anchors are active/active

**There is no anchor machine anymore.** Anchor authority lives in ONE file,
`<data_dir>/anchor.gwa` (the CA key + the door key). Any node holding it
performs anchor duties — several at once, each fully able to invite, revoke,
re-role, renew, and accept departures. Transfer = copy the file (`gw anchor
export` → scp → `gw anchor adopt`); redundancy = keep copies; cooperative
de-anchor = `gw anchor drop` (delete it) — `gw leave`, for anchors. A machine
you no longer *trust* still needs the re-root: knowledge can't be revoked.
See the new [docs/anchor.md](docs/anchor.md).

What makes concurrent holders coherent with no coordination protocol:

- **The private registry is gone; the credential IS the registry entry.**
  Hostname, caps, and expiry ride in each node's CA-signed credential inside
  its replicated NodeRecord, so issuance (enroll/renew) reads state every
  holder already converges on. Renewal re-issues from the node's record,
  verified against the trusted CA set — which also makes the old re-root
  fallback the *normal* path (a new CA recertifies the outgoing CA's nodes
  from their records, no special code). The stale sweep collapses to one
  directory prune: no record = not visible AND not renewable, convergent on
  every node by construction.
- **Membership decisions are replicated `AnchorStatement`s** (CA-signed,
  carried in /directory beside records, merged order-free by everyone):
  `revoke` (monotone, never lapses — legacy revoked.json remains a merged
  source forever), `tombstone` (a leave/sweep; kills only credentials issued
  at or before it, so departed ids re-enroll cleanly — and departures now
  reach every node on its next sync pull instead of at credential expiry),
  and `setcaps` (set-roles/set-caps, applied at the subject's next renewal by
  whichever holder serves it). Statements are re-verified against the
  current trusted set at every load, so a completed re-root's dropped CA
  takes its cached decisions with it.
- **Nodes discover the anchor SET from the directory** (records carrying the
  anchor roles under a trusted CA) and fail over across it: sync pulls from
  the first live holder, renewal tries each (verifying the returned
  credential against the trusted set — a rogue holder can't hand a node a
  credential the fleet would reject), `gw leave` departs via whichever
  answers. Holders sync from each other the same way — that IS the
  inter-holder protocol. `root_url`/`seeds` are now pure bootstrap.
- **Accepted races, made loud instead of prevented** (no consensus by
  design): same-hostname enrollments at two holders both succeed and show as
  a visible collision; a caps change racing a renewal at a not-yet-synced
  holder can bake late by one cycle; concurrent decisions about one node
  resolve latest-timestamp-wins with both in the audit trail.
- **Becoming a holder is two commands, zero file handling:** `sudo gw anchor
  offer <name>` on any holder seals the anchor file to the target's
  CA-attested WireGuard key (ephemeral X25519 → HKDF → AES-GCM) and serves it
  as a single-use, 15-minute offer on the control plane; `sudo gw anchor
  adopt` on the target collects it (authenticated + replay-guarded like a
  renewal, refused-without-consuming for any other node), opens it with its
  own key, installs, and grants itself the anchor roles. Only the machine the
  operator named can decrypt — the mesh carries ciphertext useless to
  everyone else — so there is no scp/permissions dance and no passphrase to
  shuttle. File-based `export`/`adopt <path>` remain for machines that aren't
  members yet (disaster recovery).
- New commands: `gw anchor status|init|offer|export|adopt|drop`. `gw create` mints
  the file from birth; legacy `role = anchor` configs keep working untouched
  (`gw anchor init` folds them into the file). `gw anchor-backup` now
  archives anchor.gwa + statements.json; old backups restore byte-for-byte.
- Enrollment's failed-install rollback no longer touches durable state at
  all (nothing is persisted at issue time until the joiner's record lands) —
  the ghost-hostname-squat bug class is structurally gone.

### Added

- **`gw leave` — a node voluntarily departs the mesh, removing ITSELF from the anchor.** No anchor login, no `revoke`, no waiting for the drop-grace sweep: the node sends a self-signed `LeaveRequest` (identity-key possession is the authentication, nonce+timestamp against replay — the same discipline as renewal) to a new overlay-only `POST /leave`, and the anchor forgets it — registry entry unlinked so the hostname frees immediately and renewals refuse naturally, record dropped from the directory so new syncs stop serving it. Deliberately NOT a revocation: the departing credential stays valid until expiry (revocation's own fleet-wide bound), the node cooperates by tearing its side down — daemon stopped and removed from boot, interface destroyed, hosts block cleaned — and the id can re-enroll later with a fresh invite. Local keys/config/data are kept (`gw purge` erases them), so an accidental leave is recoverable without minting a new identity. The request goes to the anchor FIRST, over the still-up tunnel; a failed or refused request changes nothing locally. Idempotent on the anchor; `event=leave` in the audit trail.
- **Complete membership history in the anchor's audit trail.** `event=leave` shipped with `gw leave`; now enrollments write a first-class `event=enroll` line (name, id, overlay address, joining IP, re-enroll flag) and `gw revoke` writes `event=revoke` — attaching the audit-file sink itself, since it runs as a CLI process outside the daemon. `grep event= audit.log` on the anchor now reads the full join/leave/revoke narrative; previously joins were only implicit in the wg command trail's ctx tags and revocations left no durable line at all.

### Fixed

- **Renewal scheduling survives clock steps.** The renewal loop slept on one long `Event.wait` computed from a single wall-clock reading — but `Event.wait` counts *monotonic* time, so a clock step under it went unnoticed. Field incident: an anchor rebooted with its clock ~87 days slow (pre-NTP), computed a 43-day delay, NTP stepped the clock forward, and the loop slept straight through its own credential's expiry — six days of an expired anchor renewing everyone but itself, with zero errors logged. The wait now runs in ≤15-minute chunks, re-deriving the delay from the current wall clock each chunk, bounding any clock step (either direction) to one chunk of damage.
- **The stale sweep can no longer reap the anchor itself.** `drop_stale`/`prune_stale` had no self-exemption: seven days after the incident above, the anchor would have deleted its own registry entry (making renewal permanently impossible) and pruned its own record from the served directory — converting a recoverable stall into a permanent mesh-wide partition. The sweep now protects the anchor's own id in both stores.
- **`gw watch`/`gw status` alarm loudly on an expired anchor.** Previously the only symptom was one dim EXPIRED cell in the roster — the mesh keeps working on the CA key, so nothing else complains. Every member's header now shouts the anchor's hostname, how long it's been expired, the partition countdown against the fleet drop grace, and the fix.
- **Endpoint auto-detection no longer elects a VPN tunnel address, and `gw join` dials every token host with real fallback.** Field incident: the anchor ran a commercial WireGuard VPN whose client address is a "global" /128 — the same one for every client of that VPN. Detection elected it (it passes the 2000::/3 GUA test), so records and invite tokens advertised an address that is NATed from the internet and LOCAL on any other machine running the same VPN; a returning node on that VPN dialed the door at its own address and hung forever. Three defenses: (1) detection now demotes /128s below real prefixes — across stability classes — and prefers the default-route interface, so a genuine /64 always beats the VPN mirage (a lone /128 is still advertised as a last resort: DHCPv6 assigns them legitimately); (2) the joiner refuses to dial a token host it itself owns, saying why; (3) the door dance tries each remaining host in order, gated on the actual WireGuard handshake (~10s per host) instead of picking one by family heuristic, and a total failure reports every host with its reason — plus a NAT-hairpin hint for v4-from-inside — instead of hanging.
- **Reconcile's "admitting expired peer" line logs once per expiry, not once per cycle.** A peer that stayed expired for days wrote the identical INFO line every reconcile cycle (~5s), burying the renewal/CA history in the journal. It now logs the admission transition only; a recertified peer that expires again logs anew.

## [0.5.0] - 2026-08-25

### Changed

- **macOS is a native platform again; the Lima-VM appliance is gone.** The macOS port (originally built and archived at tag `macos-port-archive`, then replaced by the Lima appliance) is revived and rebuilt against the seams that postdate it: `greasewood.platform` answers "which OS", `wg.py` grows a Darwin backend (wireguard-go on a `utun`, resolved from logical names via the wg-quick name-file convention; `ifconfig`/`route` primitives; socket-removal teardown; blip-free logical rename; forwarding-off door isolation; an explicit lo0 self-route), and launchd joins systemd/OpenRC as a third `ServiceManager` backend (per-mesh plists derived from the key like systemd's `%i`, RunAtLoad + KeepAlive, the async-bootout bootstrap retry). CLI detection, guards, firewall help, and status probes all go per-OS. Port enforcement is not available on macOS yet (pf backend planned) — port scopes run advisory there; tunnel existence stays fully policy-enforced. The whole Lima line — `gw-mac`, the priv helper, gateway/seal rulesets, transfer net, VM recipes, the shim formula — is deleted (preserved at tag `lima-era-archive` with the full abandonment rationale: every layer of it existed to compensate for the VM boundary, and each of vmnet's failures — dropped IPv6 fragments, dying NAT66, host-blind bridging, unsegmentable TSO delivery — was discovered empirically against a closed, undocumented layer). The brew formula now installs the real `gw` (own-venv Python, wireguard-go + wireguard-tools deps, cryptography as a wheel — still no CLT). `docs/macos.md` is rewritten around the native node and carries the VM→native migration (identity moves intact; the fleet never notices).

### Fixed

- **Two latent bugs that put any non-systemd node into a permanent 2-minute crash loop after downtime across its credential's half-life** — found live, minutes into the first launchd node's life (systemd nodes never arm the self-exit watchdog, so the fleet had never executed this code path). First: `RenewalLoop` scheduled the next renewal at half the *remaining* TTL from now — so a daemon restarting past the halfway point pushed renewal hours out on every restart, while the watchdog's renewal heuristic declared it wedged 120 seconds later and killed it, forever (the credential would simply have expired). Renewal now schedules from the credential's own timeline — halfway through its iat→exp lifetime, ±10% jitter — and a daemon already past that point renews within seconds (1–30s herd jitter); an expired-but-not-revoked credential recovers the same way. Second: the watchdog's "renewal not keeping up" margin was a flat 10 minutes, *smaller than the renewal jitter itself* (±10% of half-life = ±72 minutes at a 24h TTL), so even a healthy node whose jitter drew late would have been killed at half-life+10min roughly every other cycle. The margin is now 15% of the credential lifetime, floored at 10 minutes.

### Added

- `gw service enable|disable` — enable or disable this config's daemon service through the ServiceManager seam: the adoption path for a membership whose service was never installed on this host (a migrated config, a `--no-service` join revisited). On launchd this is the only way — there is no shared template to enable by hand.

- **macOS: the node VM's non-mesh interfaces are sealed by default.** `gw-mac` installs a small default-closed nftables ruleset (`gw-mac-lan.nft`, plus a systemd unit and an OpenRC script) into every VM it creates, and retro-fits it to an existing VM on the next `gw-mac` run. Under `vzNAT` the VM is unreachable and its listeners — sshd, mDNS, LLMNR — are closed by construction rather than by a rule; the moment the VM is given a real NIC so it can be dialled inbound, that stops being true, and greasewood's own table deliberately governs only the mesh interfaces. The seal closes everything that isn't loopback or `gw-*`, then reopens exactly what a node needs: established flows, ICMP (IPv6 does not work without it), DHCP, inbound WireGuard on the node's configured port, and Lima's host→guest ssh scoped to the RFC1918 ranges Lima's own NATs use. It seals by exclusion rather than by interface name, so which of `lima0`/`lima1` is the bridged one doesn't matter and a NIC added later is closed the day it appears. The final `drop` is counted, so `nft list table inet gwlan` answers "is the seal eating this?" without guessing.
- **macOS: a documented path to making a Mac node dialable.** `docs/macos.md` gains [Make the node dialable (bridged)](docs/macos.md) — field-tested `socket_vmnet` setup, why bridging beats pinning an endpoint by hand (only a node that can see its own address can follow a rotating residential prefix), and an honest warning that bridging over Wi-Fi puts a second MAC behind one 802.11 association and some APs drop it. Adding the NIC alongside `vzNAT` rather than replacing it makes a failed attempt a one-line revert.

### Fixed

- **Mac→mesh uploads were ~230× slower than the path allows; fixed by disabling TSO on the Mac.** With TCP segmentation offload on (the macOS default), the Mac hands multi-segment TCP trains to the vmnet virtio NIC, and Virtualization.framework delivers them into the guest as over-MTU frames without usable GSO metadata (`rx-gro-hw` is a fixed feature) — so the VM's forward path can only drop each one and emit an ICMPv6 Packet-Too-Big. Measured on a live mesh: 118 PTB drops in 4 seconds, cwnd pinned at 2 segments, 1.26 Mbit/s on a path that does 300 both as raw underlay and in the download direction (downloads never traverse Mac TSO — the asymmetry was the diagnostic tell). `gw-mac up` now asserts `net.inet.tcp.tso=0` via a new scoped priv-helper op, re-asserting after reboots; TSO's CPU saving only matters at multi-gigabit rates on real NICs. After the fix: Mac→mesh 300 Mbit/s, zero PTBs, matching the VM's own tunnel throughput.
- **`gw upgrade --from github` can no longer strand a node when the network fails mid-upgrade.** The uninstall→install sequence had the full network clone inside the window: a GitHub outage after the uninstall left greasewood removed, `gw` gone, and the daemon alive only on the deleted venv's inodes — one restart from taking the node off the mesh (exactly this happened in the field: a 133s connect timeout mid-clone; the printed recovery command was the only thread back). The repo is now cloned to local disk *before* anything is uninstalled — a fetch failure aborts with the node untouched and says so ("Nothing was changed") — and the install runs from the local clone, so only dependency wheels (usually cached) remain inside the window. If the install itself still fails, the recovery command now names the on-disk clone rather than a spec that needs the network again.
- The macOS VM recipes (Debian and Alpine) now provision `git`, so `gw upgrade --from github` — the documented way to run an unreleased fix — works in the appliance VM instead of dying with "installing from the repo needs git". Existing VMs: install it once (`sudo apt install git` / `sudo apk add git` inside the VM).
- `gw diagnose`'s link-viability verdict now respects address families. It declared a direction dialable whenever the target advertised any endpoint — so a v4-only node facing a v6-only endpoint was told "dial <v6-addr>" and then, on silence, "⚠ it isn't answering — check its host firewall", sending the operator to debug the wrong machine when the block was the dialer's own connectivity (found live: a node whose vmnet NAT66 died fell back to v4-only and diagnose blamed the healthy peer's firewall). Dialability is now the intersection of the target's endpoint families with the dialer's published `families`, matching what the reconcile loop actually does; an empty `families` (an old node that doesn't publish it) stays permissive — silence never asserts a mismatch. The mismatch case names both sides ("X advertises only ip6 endpoints and Y can only dial out on ip4"), and the isn't-answering hint fires only when the dial was actually possible.
- **The mac-gateway MSS clamp was actively causing ~10× TCP throughput loss from the Mac.** The clamp rule (`tcp flags syn tcp option maxseg size set rt mtu`) is unconditional, and on the peer's SYN-ACK being forwarded toward the Mac, `rt mtu` is the route MTU *to the Mac* (1500) — so it **raised** the peer's honest MSS (1360, sized to the tunnel) to 1440. The Mac then sent 1500-byte packets into the 1420 tunnel and every bulk Mac→peer transfer (rsync, iperf3) collapsed into PMTU-blackhole stalls: macOS's blackhole detection eventually forces the connection down to a 1280-byte path with retransmission timeouts throughout. Verified at the packet level (SYN-ACK on the Mac-facing interface carried mss 1440 before the fix, 1360 after). The rule is now scoped to `oifname "gw-*"` — clamp only SYNs entering the mesh, never rewrite advertisements leaving it. This matters doubly because Apple's vmnet silently drops IPv6 fragments between guest and host (measured: 100% loss both directions), so an overshooting packet has no fragmentation fallback; the same finding is now documented as a whole-Mac-routing caveat (large UDP/ICMPv6 mesh↔Mac cannot work). `gw-mac up` now also self-heals the gateway ruleset on existing VMs when the shipped copy differs (same philosophy as the daemon's service-template refresh), so deployed Macs pick the fix up on the next run.
- Whole-Mac overlay routing no longer depends on vmnet's NAT66 or on the VM's default route. It used to work by accident twice over: the mesh route's next hop was the `fd…` ULA vmnet's NAT66 put on `lima0` (adding a second Lima network — `lima: bridged`, to make the node dialable — rebuilds the shared bridge with v4 + link-local only, so that ULA never comes back and `gw-mac up` failed with "VM has no vzNAT IPv6 on lima0"), and the VM's replies to the Mac only found their way home because the default route pointed at vzNAT (a bridged VM's default route moves to the bridged link, which Apple's vmnet makes *host-blind* — no host↔guest traffic at all — so replies were silently dropped even once the route was fixed). `gw-mac` now gives both ends of the vzNAT link a fixed transfer address (`fd6d:6163::1/2`, applied idempotently by `gw-mac up` and at VM boot by the gateway unit): the route's next hop, and the source macOS picks for mesh-bound traffic (RFC 6724 prefers the on-interface, prefix-matching source over the `en0` GUA), which makes the reply path on-link over vzNAT by construction. The priv helper gains a `transfer-add` op, and its address validator now accepts an `%scope` suffix while still rejecting anything shell-active. Also fixed: `gw-mac`'s interactive-sudo fallback tested for a terminal on *stdin*, which the hosts-sync step pipes the hosts block into by design — so on a Mac without the autostart helper installed, every `gw-mac up` synced the route but silently refused to sync `/etc/hosts`. The check now uses stderr. `install-autostart`'s sudoers validation is now scoped to the file it installs (`visudo -c -f`) — the previous global `visudo -c` failed on unrelated `sudoers.d` files, e.g. Lima's, which is deliberately 0444 because `limactl` refuses a rule file it cannot read back.
- `gw watch`'s `reach` line read the *config* (`cfg.endpoints`) rather than the published record, so a node that gained an endpoint after joining — via `endpoint_auto`/`EndpointLoop`, which re-signs the record but never rewrites the TOML — reported "no endpoint (outbound-only)" forever while `gw diagnose` correctly reported it as dialable. It now reads the signed record, falling back to the config only before the first record exists.
- The per-interface `accept_ra=2` in `gw-mac-gateway.sysctl.conf` never took effect. `sysctl.d` is applied by `systemd-sysctl` at boot, before the interface has been renamed to `lima0`, so the write failed and was ignored (`Couldn't write '2' to 'net/ipv6/conf/lima0/accept_ra', ignoring: No such file or directory`). Its job — keeping the vzNAT link's RA-derived address and default route alive despite the gateway's `forwarding=1` — is now done where ordering is guaranteed: a systemd-networkd drop-in (`IPv6AcceptRA=yes`, which is what actually governs RA on networkd-managed images) installed beside whatever `.network` file networkd matched to the link, and in `gw-mac-gateway`'s `start()` on OpenRC, which runs after `need net`.

## [0.4.0] - 2026-08-01

### Added

- **`gw upgrade`** — upgrade a node in place, from PyPI (`--from pypi`, the default) or straight from the git repo (`--from github [--ref <branch|tag|commit>]`, for running a fix that isn't released yet). It does a clean `pipx uninstall` + `pipx install` rather than `pipx upgrade`, which has left the previous version's `__pycache__` behind in the venv, and it targets the `PIPX_HOME`/`PIPX_BIN_DIR` this install actually came from (fleet nodes use `/opt/pipx`, not pipx's default) instead of guessing. The exact commands are printed and confirmed before anything runs — the uninstall step briefly removes `gw` from a machine you may be connected through — and a failed install names the recovery command. It also prunes app symlinks pipx leaves behind in `PIPX_BIN_DIR` when a package drops an entry point (`gw-admin-upgrade`, removed in 0.3.0, was still sitting there dangling and being announced as "globally available" on every install). Finishes by restarting the mesh's daemon. `--yes` skips the prompt.

### Added

- Node records publish `families` — the underlay address families that node can originate on (`[4]`, `[6]`, `[4, 6]`), re-detected and republished when it changes. It answers a question endpoints cannot: a node behind NAT advertises no endpoint whether it's on the same LAN or on IPv4-only cafe wifi, so peers had no way to tell "it will dial me in a second" from "it genuinely cannot reach me". Unsigned and optional (like `version`), so mixed-version fleets interoperate.
- `gw watch` gains a `via` column: the underlay address family in use for each live direct tunnel (`ip6`/`ip4`), observed from live WireGuard state without reading `wg show`.
- `gw diagnose` gains a `can dial out` row: the underlay families each node can originate on. It answers what `reachable` cannot — an outbound-only node can't be dialled, but that says nothing about whether it can dial you.

### Fixed

- `reconcile` no longer drops `persistent-keepalive` to 0 when the `EndpointTracker` thinks a peer's endpoint is dead **if this node advertises no underlay endpoints of its own**. An outbound-only peer (typical laptop behind NAT) cannot be called back, so stopping keepalives after a sleep or network change meant the tunnel never recovered on its own.
- `reconcile` now keeps a post-sleep/roaming "wake window" keyed to the last anchor (or any peer, on the anchor) handshake. If the witness has not handshaked recently, the `EndpointTracker` ignores backoff so every peer gets `keepalive=25` for a settle period; once the witness recovers, the window extends further so the rest of the fleet has time to re-establish before normal backoff can resume.
- `gw-mac` and `gw-mac-priv` no longer use `python3` on the Mac side. On a fresh macOS install the system `python3` is a stub that prompts for Xcode command-line tools, so `gw-mac up` and the `/etc/hosts` sync could fail headlessly. They now use `awk` for the prefix and hosts-block rewrite.

### Known issues

- `tests/test_server.py::TestControlServerConcurrency::test_bounded_pool_sheds_load_at_capacity` is flaky on macOS: it expects a clean EOF when the anchor drops an over-capacity control-plane connection, but the OS sometimes returns `ConnectionResetError` instead. The load-shedding behavior itself is correct (the log shows `dropping a connection from ::1`). This is a test-level tolerance issue, not a product bug, and is deferred.

### Removed

- **Anchor relay has been removed.** The mesh returns to strict direct-or-fail: if two nodes cannot form a direct WireGuard tunnel, the link fails rather than being routed through the anchor. The `gw relay` command, the per-pair `relay = true` grant key, and the anchor's IPv6 forwarding/relay marker management are gone. Old signed `NodeRecord` and `GrantTable` files with `relay` fields still verify — `relay` is now a no-op legacy field — but new records and grants never set it.

## [0.3.0] - 2026-07-26

### Added

- `gw watch` now shows a `ver` column with each node's self-reported running greasewood version, so you can see at a glance which peers still need to be upgraded. The version is an unsigned display field on the directory record, so older nodes that don't parse it still verify the self-signature.

### Removed

- `gw-admin-upgrade` and the bundled `admin-upgrade.sh` script. Fleet-wide SSH upgrades were too fragile across heterogeneous `pipx`/`ssh`/`sudo` setups; the version column in `gw watch` now shows the operator what to update by hand.

## [0.2.2] - 2026-07-26

### Added

- `gw-admin-upgrade --from-mesh --user <user>`: build the SSH host list directly from the local `gw watch --json` snapshot, so fleet upgrades no longer require a manual `jq` pipeline and a host file.

## [0.2.1] - 2026-07-26

### Added

- **Relay/anchor routing**: `gw relay on` on the anchor enables forwarding for peers that cannot reach each other directly (e.g. one is IPv4-only and the other is IPv6-only). The anchor advertises a relay flag; nodes automatically route unreachable granted peers through the anchor. Direct tunnels remain preferred and are re-established as soon as they become possible. Includes `gw relay off` and `gw relay status`.

## [0.2.0] - 2026-07-26

### Added

- **Anchor failover (standby unlock)**: `gw anchor-activate` on a standby node decrypts an escrowed CA blob, rebuilds the `nodes/` registry from the directory cache, and rewrites the node as the new anchor.
- `gw anchor-standby` to re-enroll an existing live node as a failover standby.
- `failover` capability granted at `gw invite --caps failover`; enrolled nodes receive an encrypted `failover_anchor.gwbk` containing the CA key.
- Podman integration tests covering failover setup, activation, and re-invite flows.
- `gw` shim on macOS now names the node after the Mac hostname, matching Linux behavior.
- Managed-daemon auto-restart: `gw` now restarts systemd/OpenRC directly after `renew`, `rename-node`, `anchor-activate`, `anchor-promote`, `cert-request` (when SAN aliases are published), and `invite --force` CA re-key, falling back to the previous hints only when no service manager is present.
- `gw-admin-upgrade`: explicit, interactive, fault-tolerant SSH-based upgrade tool for rolling out package updates across mesh peers one host at a time. Installed as a console script and packaged so `pipx` users can run it directly (dry-run, per-host confirm, customizable command, never auto-updates silently).

### Changed

- `gw invite` packs and hands off an encrypted failover blob when the `failover` capability is present.
- `gw join` writes a `failover_anchor.gwbk` on nodes that are granted the `failover` cap.
- Alpine install recipe updated to 256 MiB RAM + an in-guest swapfile, reflecting field-tested numbers.
- Homebrew formula pinned to the v0.1.4 tarball SHA256.
- Documentation: Activity Monitor's VM number is explained as footprint, not occupancy.

### Fixed

- `DoorWatcher` now rebinds the `EnrollServer` when `door_window.json` is superseded by a new `gw invite`, so `gw watch` reports the correct door type (e.g. `OPEN (standing)`) and the retrievable token instead of continuing to show the previous single-use window.
